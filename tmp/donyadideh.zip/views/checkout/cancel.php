<?php
/**
 * @version		3.3.0
 * @package		Joomla
 * @subpackage	EShop
 * @author  	Giang Dinh Truong
 * @copyright	Copyright (C) 2012 Ossolution Team
 * @license		GNU/GPL, see LICENSE.php
 */
// no direct access
defined( '_JEXEC' ) or die(); 
?>
<h1><?php echo JText::_('ESHOP_ORDER_CANCELLED_TITLE'); ?></h1>
<p><?php echo JText::_('ESHOP_ORDER_CANCELLED_DESC'); ?></p>